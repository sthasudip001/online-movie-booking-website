-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Oct 04, 2024 at 08:18 AM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.0.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `moviebook`
--

-- --------------------------------------------------------

--
-- Table structure for table `add_movie`
--

CREATE TABLE `add_movie` (
  `id` int(25) NOT NULL,
  `movie_name` varchar(100) NOT NULL,
  `directer` varchar(100) NOT NULL,
  `release_date` varchar(100) NOT NULL,
  `categroy` varchar(100) NOT NULL,
  `language` varchar(100) NOT NULL,
  `you_tube_link` varchar(250) NOT NULL,
  `show` varchar(100) NOT NULL,
  `action` varchar(100) NOT NULL,
  `decription` varchar(300) NOT NULL,
  `image` varchar(100) NOT NULL,
  `status` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `add_movie`
--

INSERT INTO `add_movie` (`id`, `movie_name`, `directer`, `release_date`, `categroy`, `language`, `you_tube_link`, `show`, `action`, `decription`, `image`, `status`) VALUES
(9, 'Avengers', 'Kevin Feige', 'April 11, 2012', 'Science', 'English', 'https://www.youtube.com/embed/eOrNdBpGMv8', '21:00', 'running', '                                                ', 'aven.jpg', 1),
(10, 'Rampage', 'Brad Peyton', '13 April 2018', 'Adventure ', 'Hindi', '', '', 'upcoming', '                                Jumanji is a 1995 American fantasy adventure film directed by Joe Johnston from a screenplay by Jonathan Hensleigh, Greg Taylor, and Jim Strain. Loosely based on Chris Van Allsburg\'s picture book of the same name, the film is the first installment of the Jumanji franc', 'rampage.jpg', 1),
(13, 'Blink Twice', 'Christopher Landon', 'August 23, 2024', 'Thriller, Psychological', 'English', 'https://www.youtube.com/watch?v=aMcmfonGWY4', '15:00,18:15', 'running', 'A dream vacation turns into a nightmare when strange events force the protagonist to question reality, leading to a suspenseful fight for survival.', 'blink-twice.jpeg', 1),
(14, 'Borderlands', 'Eli Roth (with Tim Miller handling reshoots)', 'August 9, 2024', 'Sci-Fi, Action', 'English', 'https://www.youtube.com/watch?v=1Q8WImF649E', '18:00,15:15', 'running', '  Set on the chaotic planet of Pandora, Lilith, an infamous bounty hunter, searches for the missing daughter of the universe\'s most powerful man, facing off against aliens and bandits along the way.', 'borderland.jpg', 1),
(15, 'Playing With Fire ', 'Andrea Sedlackova', '6 November 2019', 'Comedy', 'English', 'https://www.youtube.com/embed/fd5GlZUpfaM', '21:15', 'running', '                Playing with Fire is a 2019 American family comedy film directed by Andy Fickman from a screenplay by Dan Ewen and Matt Lieberman based on a story by Ewen. The film stars John Cena, Keegan-Michael Key, John Leguizamo, Dennis Haysbert, Brianna Hildebrand and Judy Greer, and follows a ', 'movieposter_en.jpg', 1),
(17, 'It Ends With Us', 'Justin Baldoni', 'August 10, 2024', 'Drama, Romance', 'English', 'https://www.youtube.com/watch?v=r-GQvSc5ZGw', '', 'upcoming', 'A woman named Lily must navigate a complicated relationship with her neurosurgeon boyfriend while dealing with her traumatic past and the reappearance of her first love.', 'endswithus.jpeg', 1),
(21, '12gau', 'bhatta ', '220233', 'test ', '', '', '2024-10-25T05:12', 'running', '                                                ', '', 1);

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `is_active` enum('0','1') NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `name`, `email`, `password`, `is_active`) VALUES
(1, 'saujan', 'saujan@gmail.com', 'saujan123', '1'),
(2, 'Admin', 'adminfilmflexx@gmail.com', 'Password@flimflex', '1');

-- --------------------------------------------------------

--
-- Table structure for table `customers`
--

CREATE TABLE `customers` (
  `id` int(10) NOT NULL,
  `uid` int(10) NOT NULL,
  `movie` varchar(100) NOT NULL,
  `mid` int(11) DEFAULT NULL,
  `show_time` varchar(100) NOT NULL,
  `seat` varchar(100) NOT NULL,
  `totalseat` varchar(100) NOT NULL,
  `price` varchar(100) NOT NULL,
  `payment_date` varchar(100) NOT NULL,
  `booking_date` varchar(100) NOT NULL,
  `card_name` varchar(100) NOT NULL,
  `card_number` varchar(25) NOT NULL,
  `ex_date` varchar(100) NOT NULL,
  `cvv` int(5) NOT NULL,
  `custemer_id` int(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `customers`
--

INSERT INTO `customers` (`id`, `uid`, `movie`, `mid`, `show_time`, `seat`, `totalseat`, `price`, `payment_date`, `booking_date`, `card_name`, `card_number`, `ex_date`, `cvv`, `custemer_id`) VALUES
(3, 2, 'Chaal Jeevi Laiye', 0, '15:00', 'I5,I6,H5,H6,G5,G6', '6', '600', 'Thu-09-21 ', 'Fri-09-21 ', 'sunil', '45456845565', '2021-10-23', 455, 560041981),
(6, 10, 'Avengers', 0, '21:00', 'G7,A7', '2', '400', 'Thu-05-24 ', 'Fri-05-24 ', 'Saujan', '13712371823178', '2024-05-07', 121, 569640233),
(7, 11, 'Avengers', 0, '21:00', 'A11,A12', '2', '600', 'Thu-05-24 ', 'Fri-05-24 ', 'sudip', '1231312312312', '2024-05-16', 123, 1161397444),
(8, 11, 'Avengers', 0, '21:00', 'I1,H1', '', '200', 'Thu-05-24 ', 'Fri-05-24 ', 'sudip', '123131', '2024-05-22', 2132, 1008470420),
(11, 10, 'Avengers', 0, '21:00', 'I6,H6,G6', '3', '300', 'Thu-05-24 ', 'Fri-05-24 ', 'Saujan', '7182727', '2024-05-25', 121, 1724975290),
(12, 10, 'Avengers', 0, '21:00', 'I8,H8', '2', '200', 'Sat-05-24 ', 'Sun-05-24 ', 'sunil', '1231312313123', '2024-05-02', 123, 362740389),
(13, 25, 'Blink Twice', 0, '15:00', 'G11', '1', '100', 'Sun-09-24 ', 'Mon-09-24 ', 'mac', '374245455400126', '2026-05-22', 123, 1163296797),
(14, 25, 'Borderlands', 0, '18:00', 'I7,I8', '2', '200', 'Mon-09-24 ', 'Tue-09-24 ', 'mac joen', '123456789098', '2024-09-24', 1234, 1767966091),
(15, 25, 'Blink Twice', 0, '15:00', 'I7', '1', '100', 'Wed-09-24 ', 'Thu-09-24 ', 'mac', '123456678888', '2026-02-03', 1234, 1696866564),
(16, 25, 'Borderlands', 0, '15:15', 'H8', '1', '100', 'Wed-09-24 ', 'Thu-09-24 ', 'mac joen', '12345678', '2026-07-15', 1234, 1386055810),
(17, 25, 'Blink Twice', 0, '18:15', 'I7,H8', '2', '200', 'Thu-09-24 ', 'Fri-09-24 ', 'mac john', '1234567890', '2026-02-11', 1234, 1931529560),
(18, 25, 'Blink Twice', 0, '18:15', 'I7,I8', '2', '200', 'Thu-09-24 ', 'Fri-09-24 ', 'mac john', '1234567890', '2026-03-11', 1234, 161011989),
(19, 25, 'Blink Twice', 0, '18:15', 'I7,I8,I9', '3', '300', 'Thu-09-24 ', 'Fri-09-24 ', 'mac joen', '1234567890', '2026-05-05', 1234, 414789971),
(20, 25, 'Borderlands', 0, '15:15', 'I7,I8', '2', '200', 'Thu-09-24 ', 'Fri-09-24 ', 'mac joen', '1234567890', '2026-02-10', 1234, 1813941241),
(21, 25, 'Blink Twice', 0, '18:15', 'I9,I10,I11', '3', '300', 'Thu-09-24 ', 'Fri-09-24 ', 'mac', '1234567890', '2026-02-12', 1234, 1550490757),
(22, 26, '12gau', 0, '2024-10-03 18:12:28', 'H3,H7,D5,D8,A12', '5', '800', 'Thu-10-24 ', 'Fri-10-24 ', 'testuser', '4242 4242 4242 4242', '2024-10-31', 123, 448161022),
(23, 26, '12gau', 0, '2024-10-16T01:08', 'G7,F8,A7', '3', '550', 'Thu-10-24 ', 'Fri-10-24 ', 'trs', '233534534534534534', '2024-10-20', 123, 2119600875),
(25, 26, 'Avengers', 9, '21:00', 'H8,H10', '2', '200', 'Thu-10-24 ', 'Fri-10-24 ', 'tets', '32532332', '2024-10-30', 123, 1098643028),
(26, 26, 'Blink Twice', 13, '18:15', 'G9,D11', '2', '250', 'Thu-10-24 ', 'Fri-10-24 ', 'set', '123', '2024-10-09', 123, 432816353),
(27, 26, 'Avengers', 9, '21:00', 'G8,D8', '2', '250', 'Thu-10-24 ', 'Fri-10-24 ', 'dgdf', '234234', '2024-11-08', 234, 443132222),
(28, 26, '12gau', 21, '2024-10-25T05:12', 'H11,G8,F10,E10', '4', '500', 'Thu-10-24 ', 'Fri-10-24 ', 'sets', '232342332', '2024-10-25', 234, 2111038853);

-- --------------------------------------------------------

--
-- Table structure for table `feedback`
--

CREATE TABLE `feedback` (
  `id` int(100) NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(50) NOT NULL,
  `massage` varchar(100) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `feedback`
--

INSERT INTO `feedback` (`id`, `name`, `email`, `massage`) VALUES
(1, 'pratik', 'prati@gmail.com', 'Very good site'),
(59, 'Lakshay Dhoundiyal', 'lakshay22dhoundiyal@gmail.com', 'The movies are nice'),
(60, 'Ekta Arora', 'ektaarora@gmail.com', 'Testing Message');

-- --------------------------------------------------------

--
-- Table structure for table `theater_show`
--

CREATE TABLE `theater_show` (
  `id` int(25) NOT NULL,
  `show` varchar(100) NOT NULL,
  `theater` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `theater_show`
--

INSERT INTO `theater_show` (`id`, `show`, `theater`) VALUES
(1, '21:00', '1'),
(2, '15:00', '1'),
(3, '18:00', '1'),
(4, '18:15', '2'),
(5, '15:15', '2'),
(6, '21:15', '2'),
(16, '2024-10-25T05:12', '1');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id` int(25) NOT NULL,
  `username` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `mobile` bigint(20) DEFAULT NULL,
  `city` varchar(25) NOT NULL,
  `password` varchar(12) NOT NULL,
  `image` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `username`, `email`, `mobile`, `city`, `password`, `image`) VALUES
(1, 'pratik', 'prati@gmail.com', 2147483647, 'sydney', '4550', ''),
(10, 'Lakshay Dhoundiyal', 'lakshay22dhoundiyal@gmail.com', 2147483647, 'melbourne', 'lydl02@INOX', ''),
(11, 'Ekta Arora', 'ekta.arora.2512@gmail.com', 2147483647, 'perth', 'Ekta@INOX', ''),
(20, 'Sumit Dhoundiyal', 'sumit55dhoundiyal@gmail.com', 1234567890, 'perth', '123', ''),
(24, 'mac@123', 'mac@gmail.com', 1234567891, 'nsw', 'mac123', ''),
(25, 'mac123', 'mac123@gmail.com', 1234567890, 'sydney', 'mac123', ''),
(26, 'test-user', 'test@gmail.com', 8384747379, 'Lalitpur, Nepal', 'testuser', '');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `add_movie`
--
ALTER TABLE `add_movie`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `customers`
--
ALTER TABLE `customers`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `feedback`
--
ALTER TABLE `feedback`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `theater_show`
--
ALTER TABLE `theater_show`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `add_movie`
--
ALTER TABLE `add_movie`
  MODIFY `id` int(25) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `customers`
--
ALTER TABLE `customers`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=29;

--
-- AUTO_INCREMENT for table `feedback`
--
ALTER TABLE `feedback`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=62;

--
-- AUTO_INCREMENT for table `theater_show`
--
ALTER TABLE `theater_show`
  MODIFY `id` int(25) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id` int(25) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=27;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
