<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="Mark Otto, Jacob Thornton, and Bootstrap contributors">
    <meta name="generator" content="Jekyll v3.8.5">
    <title>Manageuser Page</title>


    <?php session_start();
    if (!isset($_SESSION['admin'])) {
        header("location:login.php");
    }
    ?>
    <?php include_once("./templates/top.php"); ?>
    <?php include_once("./templates/navbar.php"); ?>
    <div class="container-fluid">
        <div class="row">

            <?php include "./templates/sidebar.php"; ?>

            <div class="row">
                <div class="col-10">
                    <h2>Tickets</h2>
                </div>
                <!-- <div class="col-2">
                    <a href="#" data-toggle="modal" data-target="#add_users_modal" class="btn btn-primary btn-sm">Users detail</a>
                </div> -->
            </div>

            <div class="table-responsive">
                <table class="table table-striped table-sm">
                    <thead>
                        <tr>
                            <th>id</th>
                            <th>Movie</th>
                            <th>Tickets Available</th>
                            <th>Tickets Booked</th>
                            <th>Total Tickets</th>
                        </tr>
                    </thead>
                    <tbody id="product_list">
                        <?php
                        $i=1;
                        include_once 'Database.php';

                        // Modify the query to group by 'mid' and sum the 'totalseat'
                        $query = "SELECT mid, movie, SUM(totalseat) as total_booked 
                      FROM customers 
                      GROUP BY mid";

                        $result = mysqli_query($conn, $query);

                        if (mysqli_num_rows($result) > 0) {
                            while ($row = mysqli_fetch_array($result)) {
                                if ($row['mid']) {
                                    $totalTickets = 108;
                                    $ticketsBooked = $row['total_booked'];
                                    $ticketsAvailable = $totalTickets - $ticketsBooked;
                        ?>
                                    <tr>
                                        <td><?php echo $i; ?></td>
                                        <td><?php echo $row['movie']; ?></td>
                                        <td><?php echo $ticketsAvailable; ?></td>
                                        <td><?php echo $ticketsBooked; ?></td>
                                        <td><?php echo $totalTickets; ?></td>
                                    </tr>
                        <?php
                        $i++;
                                }
                            }
                        }
                        ?>
                    </tbody>
                </table>
            </div>
            </main>
        </div>
    </div>


    <!-- Add User Modal end -->

    <?php include_once("./templates/footer.php"); ?>